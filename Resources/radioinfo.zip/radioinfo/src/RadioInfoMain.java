import controller.Communicator;

public class RadioInfoMain {
    public static void main(String[] args) {
        new Communicator();
    }
}
